// Shared configuration. Loaded first; every other script reads from these.

// 25x25 — 1.25x the old 20x20 board. The extra ground pays for the scattered set-pieces (storage
// rooms, fountains, gardens, ponds) and for turrets/circles no longer huddling round the chamber,
// so the OPEN floor a player actually walks stays about what it was.
const WORLD_SIZE = 25; // The full board is WORLD_SIZE x WORLD_SIZE tiles (walled border).
const STARTING_VISION = 7; // The king starts seeing a 7x7 window (odd, so centered).
const VISION_STEP = 2; // Each +1 sight perk widens the window by 2 (7 -> 9 -> 11...).
const PLAYER_START = { x: 12, y: 12 }; // the board's centre
const STARTING_HP = 5; // Default; each class overrides it (see CLASSES[].hp).
// DIFFICULTY is one simple dial: starting HP, per class. Nothing else changes between settings —
// the dread clock, the spawns and the foes are identical, so Nightmare is the same dungeon met with
// a thinner skin. (Achievements badge bronze/silver/gold for easy/hard/nightmare.)
const DIFFICULTY_HP = {
  easy: { warrior: 12, ranger: 11, sorcerer: 8 },
  hard: { warrior: 9, ranger: 7, sorcerer: 5 },
  nightmare: { warrior: 5, ranger: 4, sorcerer: 3 },
};
// The DREAD CYCLE runs EIGHT steps — an 8x8 board's worth. The first three are a GRACE: the floor
// holds still, no danger event fires, and the score keeps its calm tempo. Dread then climbs across
// the remaining five, which are exactly the five HURRY tempo gears in audio.js. A step keeps the
// duration it always had (40 turns), so the grace is ADDED time — not the same ramp squeezed
// steeper. Net: a floor is quiet for 120 turns, then turns against the king over the next 200.
const DREAD_STEP_TURNS = 40;
const DREAD_GRACE_STEPS = 3; // the quiet opening — nothing stirs
const DREAD_RAMP_STEPS = 5; // must match HURRY.length in audio.js
const DREAD_TOTAL_STEPS = DREAD_GRACE_STEPS + DREAD_RAMP_STEPS; // 8 — the chess theme
const DREAD_GRACE_TURNS = DREAD_STEP_TURNS * DREAD_GRACE_STEPS; // 120
const MAX_TURNS_SCARY = DREAD_STEP_TURNS * DREAD_TOTAL_STEPS; // 320 — dread maxes here
const SPATTER_LIFE = 48; // Turns a blood spatter lingers before fading away (long — the floor gets messy).
const CORPSE_LIFE = 72; // Turns a corpse / ash / rubble / scrap / ice-shards linger before fully fading.
const BOSS_CORPSE_LIFE = 160; // A slain boss leaves remains that linger far longer than a common corpse.
// Blood that clings to a PIECE from combat (0..1 intensity, rendered as specks on its
// token). Being struck stains it heavily; landing a blow stains it lightly. It dries
// (fades) fairly quickly — see the decay in passTurn.
const BLOOD_HIT = 0.7; // splashed on a unit that IS struck
const BLOOD_STRIKE = 0.28; // splashed on a unit that DEALS a blow
const BLOOD_DRY = 0.6; // per-turn survival factor (lower = dries faster)
const PURSUIT_TTL = 6; // Turns an enemy hunts toward the king's last-seen tile before losing the trail.
const MAX_ENEMIES = 45; // Hard safety cap so over-time spawning can't run away.

// --- Floors -----------------------------------------------------------------

const FINAL_FLOOR = 8; // An eight-floor run (an 8x8-board's worth) — floor 8 is the ABSOLUTE last.
const DEMON_FLOOR = 5; // From floor 5 the fairy/demon pieces take over the roster.
// The floor-8 finale: after the Orb of Victory is taken, a single lesser boss claws in near the
// king every so often (a random BOSS_RUSH_MIN..BOSS_RUSH_MAX turns), never more than
// BOSS_RUSH_CAP of them alive at once.
const BOSS_RUSH_MIN = 10;
const BOSS_RUSH_MAX = 20;
const BOSS_RUSH_CAP = 1;
const STANDARD_KINDS = ['pawn', 'king', 'knight', 'bishop', 'rook', 'queen'];
const DEMON_KINDS = ['berolina', 'archbishop', 'chancellor', 'nightrider', 'amazon'];
// When each kind joins the roster. A kind NEVER leaves it once unlocked, and the spawn pick is
// UNIFORM across everything unlocked — so a floor is always an even mix and the low-tier pieces keep
// showing up to the end (pawn/king 50/50 → +knight 33/33/33 → +bishop/rook 20% each → +queen ~17%
// each). Nothing ever becomes "all queens".
//
// The DEMON tier restarts that curve at DEMON_FLOOR with its own five kinds, widening 2→3→4→5 over
// floors 5–8. Two unlock together on floor 5 for the same reason: one kind alone would make the
// whole floor a single repeated enemy.
//
// Demon order is MEASURED, not theoretical — average legal moves on real generated floors, weakest
// first: berolina ~1.9, nightrider ~4, archbishop ~5.8, chancellor ~6.8, amazon ~10.9. The nightrider
// reads as a monster on an open board but this dungeon is cramped, and its rides die on the first
// wall, so it lands near the bottom. Re-measure before reordering; don't trust reputations here.
const ENEMY_UNLOCKS = [
  { kind: 'pawn', floor: 1 },
  { kind: 'king', floor: 1 },
  { kind: 'knight', floor: 2 },
  { kind: 'bishop', floor: 3 },
  { kind: 'rook', floor: 3 },
  { kind: 'queen', floor: 4 },
  { kind: 'berolina', floor: 5 },
  { kind: 'nightrider', floor: 5 },
  { kind: 'archbishop', floor: 6 },
  { kind: 'chancellor', floor: 7 },
  { kind: 'amazon', floor: 8 },
];

// The eight authored floors. Each: a themed name, a terrain `recipe` (blob/segment seed counts for
// the ONLY three terrain types — wall, water, lava), and its guardian's HP. The guardian's KIND and
// NAME are NOT authored — they are rolled and derived per run (see createBoss / bossPoolForFloor /
// bossNameFor). Only `hp` stays fixed, because it is the floor-to-floor difficulty ramp. The exit +
// boss chamber sit at a fixed anchor; wanderers and potions scatter.
const LEVELS = [
  { name: 'The Battlefield', recipe: { wall: 3 }, boss: { hp: 3 } },
  { name: 'The Old Forest', recipe: { wall: 2, water: 2 }, boss: { hp: 4 } },
  { name: 'The Sunken Ruins', recipe: { wall: 6 }, boss: { hp: 4 } },
  { name: 'The Drowned Lake', recipe: { water: 8 }, boss: { hp: 5 } },
  { name: 'The Whispering Crypt', recipe: { wall: 7 }, boss: { hp: 5 } },
  { name: 'The Hedge Maze', recipe: { wall: 8 }, boss: { hp: 6 } },
  { name: 'The Lake of Fire', recipe: { lava: 8, wall: 2 }, boss: { hp: 8 } },
  { name: 'The Demon Castle', recipe: { wall: 6, lava: 3 }, boss: { hp: 14 } }, // the FINALE: a huge pool + three perks (see createBoss)
];

function levelForFloor(floor) {
  return LEVELS[((floor - 1) % FINAL_FLOOR + FINAL_FLOOR) % FINAL_FLOOR] || null;
}

function floorName(floor) {
  const level = levelForFloor(floor);
  const base = level ? level.name : `Floor ${floor}`;
  const cycle = Math.floor((floor - 1) / FINAL_FLOOR);
  return cycle > 0 ? `${base} +${cycle}` : base;
}

// Fixed exit / boss-chamber anchors, one per floor (never random). Kept clear of
// the king's central start and spread around the board's edges.
const CHAMBER_ANCHORS = [
  { x: 20, y: 20 },
  { x: 4, y: 4 },
  { x: 20, y: 4 },
  { x: 4, y: 20 },
  { x: 20, y: 12 },
  { x: 4, y: 12 },
  { x: 12, y: 20 },
  { x: 12, y: 4 },
];
function chamberAnchorForFloor(floor) {
  return CHAMBER_ANCHORS[((floor - 1) % FINAL_FLOOR + FINAL_FLOOR) % FINAL_FLOOR];
}

// Terrain unlock floors (only walls, water, lava exist now).
const TERRAIN_UNLOCK = { wall: 2, water: 3, lava: 5 };

// --- Cards ------------------------------------------------------------------

// A weapon card lets the king attack once, moving/striking like the given piece.
// Cards come in three CATEGORIES, tied to the class that grants them:
//   melee  - the king moves ONTO the target.
//   ranged - the king holds his tile; the shot is blocked by units in the way
//            (leaps excepted).
//   spell  - the king holds his tile; the bolt pierces everything on its path,
//            and costs 2x cooldown.
// A card's category is NOT stored per card — it is a property of the player's
// CLASS (Warrior melee / Ranger ranged / Sorcerer spell), resolved via
// classCategory(). There are no traits or ratings; card power comes from perks.
const STEPPER_KINDS = ['king', 'pawn', 'knight', 'mann']; // reach 1; sliders reach 3
const CARD_KINDS = ['pawn', 'king', 'knight', 'bishop', 'rook', 'archbishop', 'chancellor', 'queen', 'amazon', 'enpassant', 'doublestep', 'promotion', 'reload', 'swap', 'horse'];
const CARD_COOLDOWN = 3;
const PROMOTION_TURNS = 3; // how many turns the Ranger's Promotion (amazon form) lasts
const TURRET_HP = 3; // turrets are destructible: a flat, non-scaling HP pool (< a boss's)
const GENERAL_HP = 3; // the Necromancer's General (Necromancy T3): a lieutenant with a mini-boss's wounds

// Each floor guardian rolls ONE of these boss perks at creation, making every boss
// fight a little different. See createBoss / bossMove / damageBoss for the behaviour.
const BOSS_PERKS = ['summoner', 'blinker', 'brutal', 'ranged', 'sorcerer', 'knockback', 'shapeshifter', 'tough', 'leech', 'flying', 'phasing', 'regen'];
const BOSS_PERK_LABELS = {
  summoner: 'Summoner — conjures its own kind every third turn',
  blinker: 'Blinkborn — flickers away after each wound',
  brutal: 'Brutal — its blows land twice as hard',
  ranged: 'Volley — looses bolts down open lines instead of closing',
  sorcerer: 'Sorcerer — hurls piercing bolts through everything in their path',
  knockback: 'Bulwark — hammers the king backward with every blow',
  shapeshifter: 'Shifting — takes a new, lesser form after each wound',
  tough: 'Hardened — bears three extra wounds',
  leech: 'Leech — heals a wound each time it draws the king’s blood',
  flying: 'Winged — soars over pits, water, and lava unharmed',
  phasing: 'Phantom — sees and drifts through walls and boulders',
  regen: 'Regenerating — knits a wound shut every fourth turn',
};
// A guardian has NO unique powers — it is simply a piece kind plus rolled BOSS_PERKS, so the player
// only ever has to learn those twelve. Its KIND is rolled too, from a sliding window over its tier
// (see bossPoolForFloor), so a floor plays differently each run while still escalating. Its NAME is
// derived from kind + traits: an epithet from its primary perk over a noun hashed from the roll, so
// the same monster always earns the same name without any of it being hand-authored per floor.
// Ordered weakest→strongest within each tier.
const BOSS_TIER_MORTAL = ['knight', 'bishop', 'rook', 'queen'];
const BOSS_TIER_DEMON = ['nightrider', 'archbishop', 'chancellor', 'amazon'];
const BOSS_NOUNS = {
  knight: ['Warlord', 'Charger', 'Destrier'],
  bishop: ['Centaur', 'Inquisitor', 'Zealot'],
  rook: ['Stone Golem', 'Bastion', 'Juggernaut'],
  queen: ['Leviathan', 'Tyrant', 'Usurper'],
  nightrider: ['Bone Dragon', 'Wyrm', 'Hunter'],
  archbishop: ['Lich', 'Hierophant', 'Cardinal'],
  chancellor: ['Minotaur', 'Marshal', 'Warden'],
  amazon: ['Balrog', 'Archdemon', 'Devourer'],
};
// The epithet a guardian earns from its PRIMARY perk — so its name telegraphs its worst trait.
const BOSS_EPITHETS = {
  summoner: 'Teeming', blinker: 'Flickering', brutal: 'Brutal', ranged: 'Cruel',
  sorcerer: 'Burning', knockback: 'Hammering', shapeshifter: 'Shifting', tough: 'Hardened',
  leech: 'Thirsting', flying: 'Winged', phasing: 'Phantom', regen: 'Undying',
};
// Ordered weakest→strongest; a Shifting boss never becomes a form ranked above its origin.
const PIECE_RANK = ['pawn', 'knight', 'bishop', 'rook', 'berolina', 'nightrider', 'archbishop', 'chancellor', 'queen', 'amazon'];

function isCardKind(kind) {
  return CARD_KINDS.includes(kind);
}

// The card category shared by every card of a given class (defaults to melee).
function classCategory(className) {
  return (CLASSES[className] && CLASSES[className].category) || 'melee';
}

// How far a card reaches: steppers/knights 1 tile/leap; sliders 3 tiles. A Farsight
// perk adds `bonus` to both.
function cardReach(kind, bonus) {
  if (kind === 'doublestep') return 2 + (bonus || 0); // a fixed two-tile dash
  return (STEPPER_KINDS.includes(kind) ? 1 : 3) + (bonus || 0);
}

// Spell cards recharge twice as slowly; the king card is a touch faster.
function cardCooldown(kind, category) {
  const base = kind === 'king' ? 2 : CARD_COOLDOWN;
  return category === 'spell' ? base * 2 : base;
}

// --- Classes & level-up perks -----------------------------------------------

// Three classes, one per card category, with distinct starting HP (the melee
// Warrior is sturdiest, the fragile Sorcerer least). Each starts with a single card
// and, on every descent, chooses ONE of TWO offered perks. Perks form TIERED CHAINS:
// a perk with `requires` only appears once its prerequisite is taken, so the strong
// capstones are always gated behind cheaper stat bumps (tier 1 -> 2 -> 3).
const CLASSES = {
  warrior: {
    name: 'Warrior',
    blurb: 'A sturdy frontline fighter who lunges in and trades blows.',
    color: '#dc2626',
    category: 'melee', // every Warrior card strikes by moving onto the target
    // A knight LEAP: bound in an L onto a foe (or, now, onto empty ground) — a jumping
    // gap-closer that clears walls and pieces between. Not a piece his perks grant
    // (those give bishop & rook), so no overlap.
    start: 'knight',
    hp: 9, // the HARD baseline; the difficulty dial sets the real value (see DIFFICULTY_HP)
    // Each subclass chain has its own colour; the class colour is the starter card's.
    chains: { Sentinel: '#3b82f6', Reaver: '#b91c1c', Cavalier: '#f59e0b', Duellist: '#ec4899' },
    perks: [
      // ⛨ Sentinel — the immovable bastion: pile on HP, then shrug off the first blow.
      { id: 'w_hp1', chain: 'Sentinel', tier: 1, name: 'Hardy', desc: '+1 max HP', grants: { maxHp: 1 } },
      { id: 'w_hp2', chain: 'Sentinel', tier: 2, requires: 'w_hp1', name: 'Ironhide', desc: '+2 max HP', grants: { maxHp: 2 } },
      { id: 'w_bulwark', chain: 'Sentinel', tier: 3, requires: 'w_hp2', name: 'Parry', desc: 'The first hit each turn is negated', grants: { firstHitEachTurn: true } },
      // ⚔ Reaver — the bloodletter: kills fuel more kills.
      { id: 'w_edge', chain: 'Reaver', tier: 1, name: 'Keen Edge', desc: "A card kill cuts that card's cooldown IN HALF (rounded down)", grants: { meleeRefund: true } },
      { id: 'w_cleave', chain: 'Reaver', tier: 2, requires: 'w_edge', name: 'Cleave', desc: 'When you fell a foe, one adjacent foe dies too', grants: { meleeCleave: true } },
      { id: 'w_leech', chain: 'Reaver', tier: 3, requires: 'w_cleave', name: 'Vampiric Edge', desc: 'Any turn you fell a foe, heal 1 HP', grants: { meleeLeech: true } },
      // 🐎 Cavalier — the charger: kill on the move, trample on landing.
      { id: 'w_fleet', chain: 'Cavalier', tier: 1, name: 'Double-Step', desc: 'Gain a double-step card: dash up to 2 tiles in any direction (capturing at the end), cooldown 3', grants: { gainCard: 'doublestep', gainCooldown: 3 } },
      { id: 'w_pierce', chain: 'Cavalier', tier: 2, requires: 'w_fleet', name: 'Pierce', desc: 'A kill by moving also strikes the foe directly behind it', grants: { meleePierce: true } },
      { id: 'w_trample', chain: 'Cavalier', tier: 3, requires: 'w_pierce', name: 'Trample', desc: 'Landing a knight leap HURLS every adjacent foe back a tile (slamming it into whatever’s behind — see Knockback), rather than striking it in place', grants: { leapShock: true } },
      // 🛡 Duellist — the flashy fencer: a signature dash, free-tempo kills, a dazzling flourish.
      { id: 'w_enpassant', chain: 'Duellist', tier: 1, name: 'En Passant', desc: 'Gain an en-passant card: step 1 tile (capturing there) AND strike one foe you pass (adjacent to your start)', grants: { gainCard: 'enpassant' } },
      { id: 'w_flourish', chain: 'Duellist', tier: 2, requires: 'w_enpassant', name: 'Flourish', desc: 'After a kill, foes beside you are caught off guard', grants: { meleeFlourish: true } },
      { id: 'w_rush', chain: 'Duellist', tier: 3, requires: 'w_flourish', name: 'Charge', desc: 'The FIRST move that kills each turn costs no turn (further kill-moves that turn cost a turn as usual)', grants: { freeKillMove: true } },
    ],
  },
  ranger: {
    name: 'Ranger',
    blurb: 'A hunter who fells foes from across the room.',
    color: '#65a30d',
    category: 'ranged', // every Ranger card fires from afar (blocked by cover)
    start: 'bishop', // the Ranger opens with a DIAGONAL bow (swapped with the Sorcerer's — the shorter cooldown suits the hunter)
    startCooldown: 3, // the bishop's own cooldown
    hp: 7, // the HARD baseline (see DIFFICULTY_HP) — sturdier than a glass cannon, frailer than the warrior
    chains: { Druid: '#16a34a', Oracle: '#14b8a6', 'Gloom Stalker': '#6366f1', Marksman: '#a3e635' },
    perks: [
      // 🌲 Druid — the survivalist: master the terrain, then ride to war.
      { id: 'r_wade', chain: 'Druid', tier: 1, name: 'Fairy Wings', desc: 'You flit over water, lava, and pits — walking, carding, or leaping onto and across them freely, with no slow, no burn, and no falling', grants: { terrainImmune: true } },
      { id: 'r_xray', chain: 'Druid', tier: 2, requires: 'r_wade', name: 'Wild Empathy', desc: 'Beasts of the wild — enemy and mini-boss knights and amazons (never a floor boss) — never attack you, and the moment you SEE one it bows and JOINS your side, fighting as your ally (until you strike it, which breaks the bond)', grants: { beastFriend: true } },
      { id: 'r_promo', chain: 'Druid', tier: 3, requires: 'r_xray', name: 'Animal Form', desc: 'Gain an Animal Form card (cooldown 9): become an INVINCIBLE beast — an AMAZON (slides like a queen AND leaps like a knight) — for 3 turns, taking no damage and playing no cards', grants: { gainCard: 'promotion', gainCooldown: 9 } },
      // 🎯 Oracle — the seer: know the floor, then see (and shoot) beyond your foes' sight.
      { id: 'r_eagle', chain: 'Oracle', tier: 1, name: 'Premonition', desc: 'Cover no longer blinds you: within your sight radius you SEE and SHOOT straight through walls, boulders, and devilgrass. It is ONE-WAY — a foe with a wall between you can’t strike back, but it DOES wake and start closing in on you', grants: { seeThroughWalls: true } },
      { id: 'r_eyes2', chain: 'Oracle', tier: 2, requires: 'r_eagle', name: 'Hawk Eyes', desc: '+1 sight radius AND +1 card reach. This extra sight is ONE-WAY — foes out in the new band can’t see or strike you back (though they’ll start closing in)', grants: { visionOneWay: 2, cardReach: 1 } },
      { id: 'r_reach', chain: 'Oracle', tier: 3, requires: 'r_eyes2', name: 'Power Draw', desc: '+1 sight radius AND +1 card reach (again) — the extra sight is likewise one-way, so you pick foes off from outside their reach', grants: { visionOneWay: 2, cardReach: 1 } },
      // 🌑 Gloom Stalker — the ghost: unchased, ignored by structures, unnoticed.
      // Ghost used to grant `noChase` (foes gave up the moment you broke sight). That read as
      // stealth but PUNISHED good play: it made a foe impossible to draw off its pack, so you could
      // never isolate one. It now slows the CATCHING of your eye instead of ending the chase.
      { id: 'r_ghost', chain: 'Gloom Stalker', tier: 1, name: 'Ghost', desc: 'Foes are slow to fix on you: one more than a tile away has only a 50% chance each turn to notice you at all — so you can draw a single foe off a pack and fight it alone. Adjacent, it always sees you, and one you have struck is enraged regardless', grants: { elusive: true } },
      { id: 'r_camo', chain: 'Gloom Stalker', tier: 2, requires: 'r_ghost', name: 'Camouflage', desc: 'Turrets and summoning circles more than one tile away are BLIND to you — turrets doze (a sleep “z”) and never fire, circles conjure nothing. Step adjacent (within one tile) and they wake and work as normal', grants: { camouflage: true } },
      { id: 'r_stealth', chain: 'Gloom Stalker', tier: 3, requires: 'r_camo', name: 'Silent', desc: 'Foes never notice or attack you unless you are adjacent (within one tile) — even firing a weapon won’t give you away. A wandering foe can still blunder onto your tile, striking you by accident', grants: { stealth: true } },
      // 🏹 Marksman — the sharpshooter: kickback, a big bow, then exploding shots.
      { id: 'r_recoil', chain: 'Marksman', tier: 1, name: 'Recoil', desc: 'Firing a weapon card kicks you one tile back from the target (striking a foe there) AND shoves every adjacent foe back one tile where the ground behind it is clear', grants: { recoil: true } },
      { id: 'r_longbow', chain: 'Marksman', tier: 2, requires: 'r_recoil', name: 'Ballista', desc: 'Gain a queen card (cooldown 9) — a devastating volley in any direction', grants: { gainCard: 'queen', gainCooldown: 9 } },
      { id: 'r_shrapnel', chain: 'Marksman', tier: 3, requires: 'r_longbow', name: 'Shrapnel', desc: 'Every weapon card you fire SHATTERS on impact — striking every foe adjacent to the tile you hit, as well as the target', grants: { shrapnel: true } },
    ],
  },
  sorcerer: {
    name: 'Sorcerer',
    blurb: 'A fragile caster whose bolts pierce straight through the ranks.',
    color: '#a855f7',
    category: 'spell', // every Sorcerer card is a bolt that pierces the whole path
    start: 'rook', // the Sorcerer opens with an ORTHOGONAL piercing bolt (swapped with the Ranger's)
    startCooldown: 5, // the rook's own cooldown
    hp: 5, // the HARD baseline (see DIFFICULTY_HP) — the frailest of the three
    // Four subclass chains, each a full 3-tier build (Necromancy is the ally-summoning line).
    chains: { Translocations: '#22d3ee', Necromancy: '#65a30d', Hexes: '#e879f9', Conjuration: '#8b5cf6' },
    perks: [
      // 🔮 Translocations — the blink-mage: dodge, phase, and displace.
      { id: 's_blink', chain: 'Translocations', tier: 1, name: 'Blink', desc: 'When a foe hits you, blink to a random safe tile in sight (if any)', grants: { blink: true } },
      { id: 's_phase', chain: 'Translocations', tier: 2, requires: 's_blink', name: 'Phase', desc: 'Move onto wall AND ice tiles; while embedded in opaque cover (a wall or boulder) your sight shrinks', grants: { phase: true } },
      { id: 's_swap', chain: 'Translocations', tier: 3, requires: 's_phase', name: 'Displacement', desc: 'Gain a swap card: trade places with any unit in sight (cooldown 3); arriving knocks every other adjacent foe back a tile', grants: { gainCard: 'swap', gainCooldown: 3 } },
      // 💫 Hexes — the curse-weaver: demote, dazzle, and lull.
      { id: 's_hex', chain: 'Hexes', tier: 1, name: 'Hex', desc: 'At the start of each turn, one foe adjacent to you is warped into a confused ferz — a feeble one-step diagonal mover (bosses and structures are immune)', grants: { hexDemote: true } },
      { id: 's_cata', chain: 'Hexes', tier: 2, requires: 's_hex', name: 'Cataclysm', desc: 'Every visible enemy is surprised when you cast a spell', grants: { spellSurprise: true } },
      { id: 's_slumber', chain: 'Hexes', tier: 3, requires: 's_cata', name: 'Slumber', desc: 'Non-boss foes adjacent to you fall asleep', grants: { sleepAura: true } },
      // 🌀 Conjuration — the artillery-mage: reach, a queen, then a full barrage.
      { id: 's_amp', chain: 'Conjuration', tier: 1, name: 'Blast', desc: 'Any foe your spell strikes but does NOT kill (a boss, mini-boss, or turret) is HURLED one tile along the bolt’s path — a concussive shockwave', grants: { spellBlast: true } },
      { id: 's_staff', chain: 'Conjuration', tier: 2, requires: 's_amp', name: 'Phantom Steed', desc: 'Gain a horse card: a spectral steed that tramples an L-shaped path, scorching every foe along it (cooldown 4)', grants: { gainCard: 'horse', gainCooldown: 4 } },
      { id: 's_barrage', chain: 'Conjuration', tier: 3, requires: 's_staff', name: 'Double Cast', desc: 'After firing a spell, if a targetable foe remains you may aim and fire once more before your turn ends', grants: { doubleCast: true } },
      // 🔥 Necromancy — the summoner: a familiar, then undead, then a General.
      { id: 's_familiar', chain: 'Necromancy', tier: 1, name: 'Familiar', desc: 'Summon a skeletal MANN familiar (steps one tile any direction) that follows you, fights foes, and respawns each floor / when clear', grants: { familiar: true } },
      { id: 's_undead', chain: 'Necromancy', tier: 2, requires: 's_familiar', name: 'Grave Bond', desc: 'A foe you slay rises as an undead ally (one at a time; undead do not follow you downstairs)', grants: { necromancy: true } },
      { id: 's_general', chain: 'Necromancy', tier: 3, requires: 's_undead', name: 'Undead General', desc: 'Your familiar becomes an Undead General — a king that can also leap like a knight', grants: { generalForm: true } },
    ],
  },
};

// Flat lookup: subclass chain name -> its colour (chain names are unique across classes).
const SUBCLASS_COLORS = {};
for (const cls of Object.values(CLASSES)) {
  for (const [chainName, color] of Object.entries(cls.chains || {})) SUBCLASS_COLORS[chainName] = color;
}
// The colour a granted card should wear: its subclass colour, else the class colour.
function chainColorFor(className, chainName) {
  const cls = CLASSES[className];
  return (cls && cls.chains && cls.chains[chainName]) || (cls && cls.color) || '#888';
}
// The colour the king's own token wears: his base class colour, UPGRADED to a subclass
// colour once he earns that chain's tier-3 capstone (the most recent capstone wins).
function playerDisplayColor(player) {
  const className = (player && player.className) || 'warrior';
  const cls = CLASSES[className] || CLASSES.warrior;
  let color = cls.color;
  for (const id of (player && player.takenPerks) || []) {
    const perk = cls.perks.find((k) => k.id === id);
    if (perk && perk.tier === 3) color = chainColorFor(className, perk.chain);
  }
  return color;
}
const LEVEL_PERK_CHOICES = 2; // perks offered per descent

// Movement direction tables, reused by the piece-move generators.
const ORTHO = [
  [1, 0],
  [-1, 0],
  [0, 1],
  [0, -1],
];
const DIAG = [
  [1, 1],
  [1, -1],
  [-1, 1],
  [-1, -1],
];
const KNIGHT_STEPS = [
  [1, 2],
  [2, 1],
  [-1, 2],
  [-2, 1],
  [1, -2],
  [2, -1],
  [-1, -2],
  [-2, -1],
];

// localStorage key for the single save slot.
const SAVE_KEY = 'chess-roguelike-save-v2';
